import Cocoa

var celcius = 100
var farnehite = ((9*celcius)/5)+32

print(farnehite)
print(celcius)
