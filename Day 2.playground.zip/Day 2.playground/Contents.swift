import Cocoa

let album = ["taylor swift", "scooter braun", "coldplay", "coldplay"]
print(album.count)
let unique = Array(Set(album))
print(unique)
